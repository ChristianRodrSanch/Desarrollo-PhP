<?php

$numeroDado = 2340;

for($i=0;$i < strlen($numeroDado); $i++ ) {

    echo pow($numeroDado,10);

}

// incompleto no tengo mucha idea de como hacerlo he buscado por internet me sale para hacerlo strlen y pow pero no se como utilizarlo aqui