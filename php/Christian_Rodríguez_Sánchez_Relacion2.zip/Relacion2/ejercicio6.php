<?php

// Ejercicio 6: Escribe una función llamada intercambiar() que reciba dos variables por referencia e intercambie
// sus valores.

function intercambiar(int $refer1, int $refer2) {

    $valorAux1 = $refer1;
    echo "Los valores originales son $refer1 y $refer2 <br>";
    $refer1 = $refer2;
    $refer2 = $valorAux1;

    echo "Los valores intercambiados son $refer1 y $refer2";


}


intercambiar(10,20);