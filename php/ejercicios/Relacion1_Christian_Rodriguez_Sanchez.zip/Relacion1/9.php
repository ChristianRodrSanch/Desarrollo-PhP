<?php

    $a = 5;
    $b = 1;
    $c = 2;

        if($a !== 0) {
            $x = ($c - $b)/$a;
            echo "La solucion de la ecuacion es: $x";
        }else {
            echo "El valor a no puedes ser igual a 0";
        }