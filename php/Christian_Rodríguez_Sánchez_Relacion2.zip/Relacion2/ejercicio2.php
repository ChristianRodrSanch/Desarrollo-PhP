<?php

// Ejercicio 2: Desarrolla un programa que reciba un número de mes (1, 12) y un número de día de la semana (1, 7) y
// devuelva el nombre del mes, el nombre del día de la semana y el número de días de dicho mes (sin tener en cuenta los
// bisiestos). Haremos control de errores, es decir, si el número de mes no está entre 1 y 12 o el número del día de la
// semana entre 1 y 7 mostraremos un mensaje de error.

$meses = [
    'Enero' => 1,
    'Febrero' => 2,
    'Marzo' => 3,
    'Abril' => 4,
    'Mayo' => 5,
    'Junio' => 6,
    'Julio' => 7,
    'Agosto' => 8,
    'Septiembre' => 9,
    'Octubre' => 10,
    'Noviembre' => 11,
    'Diciembre' => 12

];

$dias = [
    'Lunes' => 1,
    'Martes' => 2,
    'Miercoles' => 3,
    'Jueves' => 4,
    'Viernes' => 5,
    'Sabado' => 6,
    'Domingo' => 7,
];

var_dump($meses);